# Skills Bônus - Máquina de Edição IA

3 skills autorais para briefing, legendas/enquadramento e revisão com economia de retrabalho. Kit incluído no treinamento.

## Seu primeiro uso

1. Extraia o ZIP mantendo as pastas juntas.
2. Abra painel/index.html no navegador.
3. Entre em Como usar e siga a instalação no projeto de edição.
4. Selecione uma skill ou um modelo. Preencha os campos entre colchetes.
5. Copie o comando e envie ao agente com os arquivos correspondentes.
6. Confira uma amostra em movimento antes de ampliar uma direção ainda não aprovada.

No painel, os campos preenchidos ficam salvos apenas neste navegador. Nenhum arquivo de vídeo é enviado pelo painel. Ele é uma biblioteca local de instruções; a edição acontece no projeto aberto no agente.

Não cole todas as skills em cada pedido. Use a orientação ligada ao trabalho do momento. Um modelo previsível define composição e critérios; não promete um resultado visual idêntico em qualquer gravação.

## O que depende de você

Tenha os originais, uma mensagem correta e materiais que possa usar. Confira nomes, números, ofertas, legendas, rosto, áudio e o CTA real. O treinamento ensina o ambiente; este pacote organiza a direção e os comandos. Planos de IA, uso de API e serviços extras seguem suas próprias condições.
